import { ApiTypes } from '../types/types';
import { BlogsRepository } from './blogs-db-repository';
import { blogsCollection, postsCollection, usersCollection } from "./db";

interface IReqAllBlogs {
	searchNameTerm: string;
	pageNumber: string;
	pageSize: string;
	sortBy: string;
	sortDirection: string;
}

interface IReqAllPosts {
	pageNumber: string;
	pageSize: string;
	sortBy: string;
	sortDirection: string;
}

const DEFAULT_PROJECTION = { _id: false };

export class QueryRepository {
	static async getAllBlogs(params: IReqAllBlogs) {
		try {
			let { searchNameTerm, pageNumber, pageSize, sortBy, sortDirection } = params;
			let skip = (+pageNumber - 1) * +pageSize;

			let result = await blogsCollection.find(
				{ name: { $regex: searchNameTerm, $options: "$i" } },
				{ projection: {...DEFAULT_PROJECTION} }
			)
				.skip(+skip)
				.limit(+pageSize)
				.sort({ [sortBy]: sortDirection == "asc" ? 1 : -1 })
				.toArray();

			let totalCount = await blogsCollection.countDocuments({ name: { $regex: searchNameTerm, $options: "$i" } });
			let pageCount = Math.ceil(totalCount / +pageSize);

			return {
				pagesCount: pageCount,
				page: +pageNumber,
				pageSize: +pageSize,
				totalCount: totalCount,
				items: result
			}

		} catch (error) {
			console.log("Error: ", error);
		}
	}

	static async getOneBlog(id: string): Promise<ApiTypes.IBlog | null> {
		try {
			return await blogsCollection.findOne({ id }, { projection: { ...DEFAULT_PROJECTION } });
		} catch (error) {
			console.error(error);
			return null;
		}
	}

	static async getPosts(queries: IReqAllPosts, blogId?: string) {
		try {
			let { pageNumber, pageSize, sortBy, sortDirection } = queries;
			let skip = (+pageNumber - 1) * +pageSize;
			let filter: any = {};

			if (blogId) {
				filter.blogId = blogId;
			}

			let result = await postsCollection.find(
				filter,
				{ projection: { ...DEFAULT_PROJECTION } }
			)
				.skip(+skip)
				.limit(+pageSize)
				.sort({ [sortBy]: sortDirection == "asc" ? 1 : -1 })
				.toArray();

			let totalCount = await postsCollection.countDocuments(filter, {});
			let pageCount = Math.ceil(totalCount / +pageSize);

			return {
				pagesCount: pageCount,
				page: +pageNumber,
				pageSize: +pageSize,
				totalCount: totalCount,
				items: result
			}
		} catch (error) {
			console.log("Error: ", error);
		}
	}

	static async getOnePost(id: string): Promise<ApiTypes.IPost | null> {
		try {
			return await postsCollection.findOne({ id }, { projection: { ...DEFAULT_PROJECTION } });
		} catch (error) {
			console.error(error);
			return null;
		}
	}

	static async getUser(login: string): Promise<ApiTypes.IUserDB | null>{
		try {
			return await usersCollection.findOne({login}, {projection: { ...DEFAULT_PROJECTION }} )
		} catch (error) {
			console.error(error);
			return null;
		}
	}

	static async getAllUser(): Promise<ApiTypes.IUserDB[] | null>{
		try {
			return await usersCollection.find({}, {projection: { ...DEFAULT_PROJECTION }} ).toArray();
		} catch (error) {
			console.error(error);
			return null;
		}
	}
}