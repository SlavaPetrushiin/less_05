import { checkAuth } from './../utils/checkAuth';
import { UsersService } from './../services/users_service';
import { checkError } from './../utils/checkError';
import express, { Request, Response } from 'express';
import { userValidator } from '../validators/usersValidator';

interface ICreateUserInput {
	login: string;
	password: string;
	email: string;
}

interface IQueryUsers {
	searchLoginTerm?: string;
	searchEmailTerm?: string;
	pageNumber?: string;
	pageSize?: string;
	sortBy?: string;
	sortDirection?: string;
}

export const routerUsers = express.Router();

routerUsers.get("/", checkAuth, async (req: Request<{}, {}, {}, IQueryUsers>, res: Response) => {
	let {pageNumber, pageSize, searchEmailTerm, searchLoginTerm, sortBy, sortDirection} = req.query;
	res.send(1)
})

routerUsers.post("/", checkAuth, userValidator, checkError, async (req: Request<{}, {}, ICreateUserInput>, res: Response) => {
	let {email, login, password} = req.body;
	let newUser = await UsersService.createUser(email, login, password);
	if(!newUser){
		return res.sendStatus(404);
	}
	return res.status(201).send(newUser);
})

routerUsers.delete("/:id", checkAuth, async (req: Request<{id: string}>, res: Response) => {
	let {id} = req.params;
	console.log("SSSSSSS: ", id);
	let isDeleted = await UsersService.deleteUser(id);

	if(!isDeleted){
		return res.sendStatus(404);
	}
	return res.sendStatus(204);
})