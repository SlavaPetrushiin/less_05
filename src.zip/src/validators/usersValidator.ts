import { body } from "express-validator";

const checkEmail = (email: string) => {
	let pattern = new RegExp('^[\w\.]+@([\w-]+\.)+[\w-]{2,4}$');
	return pattern.test(email);
} 

export const userValidator = [
	body("login").isString().isLength({min: 3, max: 10}).withMessage("KJuby должен быть от 3 до 10 символов"),
	body("password").isString().isLength({min: 6, max: 20}).withMessage("Пароль должен быть от 6 до 20 символов"),
	// body("email").isString().custom(checkEmail).withMessage("Укажите валидный email"),
];